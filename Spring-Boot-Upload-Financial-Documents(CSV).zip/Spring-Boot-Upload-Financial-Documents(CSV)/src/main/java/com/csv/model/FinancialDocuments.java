package com.csv.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "financial_documents")
public class FinancialDocuments {

  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  @Column(name = "invoiceNo")
  private long invoiceNo;

  @Column(name = "bankTransactionRefNo")
  private String bankTransactionRefNo;

  @Column(name = "typeOfTransaction")
  private String typeOfTransaction;

  @Column(name = "amount")
  private double amount;
  
  @Column(name = "transactionDate")
  private String transactionDate;

  public FinancialDocuments() {

  }

/**
 * @param invoiceNo
 * @param bankTransactionRefNo
 * @param typeOfTransaction
 * @param amount
 * @param transactionDate
 */
public FinancialDocuments(long invoiceNo, String bankTransactionRefNo, String typeOfTransaction, double amount,
		String transactionDate) {
	super();
	this.invoiceNo = invoiceNo;
	this.bankTransactionRefNo = bankTransactionRefNo;
	this.typeOfTransaction = typeOfTransaction;
	this.amount = amount;
	this.transactionDate = transactionDate;
}

public long getInvoiceNo() {
	return invoiceNo;
}

public void setInvoiceNo(long invoiceNo) {
	this.invoiceNo = invoiceNo;
}

public String getBankTransactionRefNo() {
	return bankTransactionRefNo;
}

public void setBankTransactionRefNo(String bankTransactionRefNo) {
	this.bankTransactionRefNo = bankTransactionRefNo;
}

public String getTypeOfTransaction() {
	return typeOfTransaction;
}

public void setTypeOfTransaction(String typeOfTransaction) {
	this.typeOfTransaction = typeOfTransaction;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public String getTransactionDate() {
	return transactionDate;
}

public void setTransactionDate(String transactionDate) {
	this.transactionDate = transactionDate;
}

@Override
public String toString() {
	return "FinancialDocuments [invoiceNo=" + invoiceNo + ", bankTransactionRefNo=" + bankTransactionRefNo
			+ ", typeOfTransaction=" + typeOfTransaction + ", amount=" + amount + ", transactionDate=" + transactionDate
			+ "]";
}

 

}
