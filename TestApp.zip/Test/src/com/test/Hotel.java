package com.test;

import java.util.List;
import java.util.Scanner;


public class Hotel {
	
	 	
	public static void order(int menuItem) {
		processOrder(menuItem);
		
		
	}

	public static void processOrder(int order) {
		      switch (order) {
		          case 1:
		        	 // Idli.noOfPlates(order);
		        	 // System.out.println("You have order one 1 plate");
		             // ItemImpl idli=new ItemImpl();
		          	//  idli.quantity(2);
		          	  
		              break;
		          case 2:
		              System.out.println("You have order 2 plate");
		              break;
		          case 3:
		              System.out.println("You have order 3 plate");
		              break;
		          default:
		              System.out.println("You have order 4 plate");
		              break;
		      }
		  
		// TODO Auto-generated method stub
		
	}


}
