package com.test;


import java.util.ArrayList;

public class MenuItem {
	public static ArrayList<String> menyItemList=new ArrayList<>();
	public ArrayList<String> getMenuItem() {
		 menyItemList.add("Idli");
		 menyItemList.add("Samosa");
		 //System.out.println(list);
		return menyItemList;
		
	}
	
	public String getMenu() {
		
		String menu="";
		int count=1;
		for(String menuOrder:menyItemList) {
			String j=count+". "+menuOrder+" \n";
			count++;
			menu=menu+j;
		}
		menu.trim();
		
		return menu;
	}

}
