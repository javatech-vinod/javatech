package com.test;
	import java.util.*;
	public class TestApp{
	 @SuppressWarnings("resource")
	public static void main(String[] args) {
		 System.out.println("Welcome to Raj Hotel:");
		 Scanner scan1 =null;
		 Scanner scan =null;
		 System.out.println("Menu Card:");
		 MenuItem item =new MenuItem();
		 item.getMenuItem();
		 System.out.println(item.getMenu());//
				
		 scan1 = new Scanner(System.in);
		
		 System.out.println("Please choose menu 1 for Idli:");
		 int name=scan1.nextInt();
		 Hotel.order(name);
		 
		 scan = new Scanner(System.in);
		 System.out.println("Please Enter how many plate of order:");
		 int plates=scan.nextInt();
		 Idli.noOfPlates(plates);
		

	 }
}
