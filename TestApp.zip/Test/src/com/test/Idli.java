package com.test;

public class Idli {
	public Idli() {
		System.out.println("Welcome to Idli Center");
	}
	
	public static void noOfPlates(int plates) {
		if(plates==1){
			System.out.println("You have ordered 1 plate Idli");
		}else if(plates==2) {
			System.out.println("You have ordered 2 plate Idli");
			
		}
		else {
			System.out.println("You have ordered 1 plate Idli");
		}
		System.out.println("Thank you for purchase quantity units of idli\r\n" + 
				"		welcome again!");
	}

}
